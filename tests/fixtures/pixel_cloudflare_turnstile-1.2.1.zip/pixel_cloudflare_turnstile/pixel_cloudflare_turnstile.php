<?php
/**
 * Copyright (c) Since 2022 Pixel Développement and contributors
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Addon\Theme\ThemeProviderInterface;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class Pixel_cloudflare_turnstile extends Module implements WidgetInterface
{
    public const TURNSTILE_SESSION_ERROR_KEY = 'turnstile_error';

    public const CONFIG_CLOUDFLARE_TURNSTILE_SITEKEY = 'CLOUDFLARE_TURNSTILE_SITEKEY';
    public const CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY = 'CLOUDFLARE_TURNSTILE_SECRET_KEY';
    public const CONFIG_CLOUDFLARE_TURNSTILE_THEME = 'CLOUDFLARE_TURNSTILE_THEME';
    public const CONFIG_CLOUDFLARE_TURNSTILE_FORMS = 'CLOUDFLARE_TURNSTILE_FORMS';
    public const CONFIG_CLOUDFLARE_TURNSTILE_APPEARANCE = 'CLOUDFLARE_TURNSTILE_APPEARANCE';
    public const CONFIG_CLOUDFLARE_TURNSTILE_TEST_MODE = 'CLOUDFLARE_TURNSTILE_TEST_MODE';

    public const TEST_MODE_DISABLED = 'disabled';
    public const TEST_MODE_PASS = 'pass';
    public const TEST_MODE_FAIL = 'fail';
    public const TEST_MODE_INTERACTIVE = 'interactive';

    protected const TEST_KEYS = [
        self::TEST_MODE_PASS => [
            'sitekey_visible'   => '1x00000000000000000000AA',
            'sitekey_invisible' => '1x00000000000000000000BB',
            'secret'            => '1x0000000000000000000000000000000AA',
        ],
        self::TEST_MODE_FAIL => [
            'sitekey_visible'   => '2x00000000000000000000AB',
            'sitekey_invisible' => '2x00000000000000000000BB',
            'secret'            => '2x0000000000000000000000000000000AA',
        ],
        self::TEST_MODE_INTERACTIVE => [
            'sitekey_visible'   => '3x00000000000000000000FF',
            'sitekey_invisible' => '3x00000000000000000000FF',
            'secret'            => '1x0000000000000000000000000000000AA',
        ],
    ];

    public const FORM_CONTACT = 'contact';
    public const FORM_LOGIN = 'login';
    public const FORM_REGISTER = 'register';
    public const FORM_PASSWORD = 'password';
    public const FORM_NEWSLETTER = 'newsletter';

    protected $templateFile;

    protected static $validationError;

    /**
     * Module's constructor.
     */
    public function __construct()
    {
        $this->name = 'pixel_cloudflare_turnstile';
        $this->version = '1.2.1';
        $this->author = '30knees';
        $this->tab = 'front_office_features';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans(
            'Cloudflare Turnstile',
            [],
            'Modules.Pixelcloudflareturnstile.Admin'
        );
        $this->description = $this->trans(
            'Protect your store from spam messages and spam user accounts.',
            [],
            'Modules.Pixelcloudflareturnstile.Admin'
        );
        $this->ps_versions_compliancy = [
            'min' => '9.2.0',
            'max' => '9.2.99',
        ];

        $this->templateFile = 'module:' . $this->name . '/pixel_cloudflare_turnstile.tpl';
    }

    /***************************/
    /** MODULE INITIALIZATION **/
    /***************************/

    /**
     * Install the module
     *
     * @return bool
     */
    public function install(): bool
    {
        if (!$this->checkRuntime()) return false;
        if (!parent::install()) return false;
        if (!$this->registerHook([
            'actionFrontControllerSetMedia', 'displayCustomerAccountForm',
            'displayNewsletterRegistration', 'actionNewsletterRegistrationBefore',
            'actionFrontControllerInitBefore',
        ])) {
            parent::uninstall();
            return false;
        }
        return true;
    }

    public function uninstall(): bool
    {
        // Reset uses uninstall/install; keep every configuration scope and credential.
        return parent::uninstall();
    }

    public function checkRuntime(): bool
    {
        if (PHP_VERSION_ID < 80500 || PHP_VERSION_ID >= 80600
            || version_compare(_PS_VERSION_, '9.2.0', '<') || version_compare(_PS_VERSION_, '9.2.99', '>')) {
            $this->_errors[] = 'Requires PrestaShop 9.2.x and PHP 8.5.';
            return false;
        }
        return true;
    }

    public function runUpgradeModule()
    {
        if (!$this->checkRuntime()) throw new PrestaShopException('Requires PrestaShop 9.2.x and PHP 8.5.');
        return parent::runUpgradeModule();
    }

    /**
     * Use the new translation system
     *
     * @return bool
     */
    public function isUsingNewTranslationSystem(): bool
    {
        return true;
    }

    /***********/
    /** HOOKS **/
    /***********/

    /**
     * Adds CSS and JS
     *
     * @return void
     */
    public function hookActionFrontControllerSetMedia(): void
    {
        $this->context->controller->registerStylesheet(
            'cloudflare-turnstile',
            'modules/' . $this->name . '/views/css/turnstile.css',
            [
                'position'   => 'head',
                'priority'   => 100,
            ]
        );
        $this->context->controller->registerJavascript(
            'cloudflare-turnstile',
            'https://challenges.cloudflare.com/turnstile/v0/api.js',
            [
                'server'     => 'remote',
                'position'   => 'head',
                'priority'   => 100,
                'attributes' => 'async',
            ]
        );
    }

    /**
     * Display turnstile widget on the create account form
     *
     * @return string
     */
    public function hookDisplayCustomerAccountForm(): string
    {
        if ($this->context->customer->isLogged()) {
            return '';
        }
        if (!$this->isAvailable(self::FORM_REGISTER)) {
            return '';
        }
        return $this->renderWidget('displayCustomerAccountForm', []);
    }

    /**
     * Turnstile validation
     *
     * @param array $params
     *
     * @return void
     * @throws Exception
     */
    public function hookActionFrontControllerInitBefore(array $params): void
    {
        if (!$this->canProcess(get_class($params['controller']))) {
            return;
        }

        if (!$this->getSecretKey()) {
            $this->context->controller->errors[] = $this->trans(
                'Cloudflare turnstile secret key is missing',
                [],
                'Modules.Pixelcloudflareturnstile.Shop'
            );
            return;
        }
        if (!$this->getSitekey()) {
            $this->context->controller->errors[] = $this->trans(
                'Cloudflare turnstile sitekey is missing',
                [],
                'Modules.Pixelcloudflareturnstile.Shop'
            );
            return;
        }

        $cookie = Context::getContext()->cookie;

        if ($cookie->__get(self::TURNSTILE_SESSION_ERROR_KEY)) {
            $this->context->controller->errors[] = $this->trans(
                $cookie->__get(self::TURNSTILE_SESSION_ERROR_KEY),
                [],
                'Modules.Pixelcloudflareturnstile.Shop'
            );
            $cookie->__unset(self::TURNSTILE_SESSION_ERROR_KEY);
        }

        if ($this->canProcess(get_class($params['controller']), true)) {
            $this->turnstileValidationAndRedirect();
        }
    }

    /**
     * Display turnstile widget on the create account form
     *
     * @return string
     */
    public function hookDisplayNewsletterRegistration($params)
    {
        if (!$this->isAvailable(self::FORM_NEWSLETTER)) {
            return '';
        }

        return $this->renderWidget('displayNewsletterRegistration', []);
    }

    /**
     * Hook to validate newsletter registration
     *
     * @param array $params
     *
     * @return void
     *
     */
    public function hookActionNewsletterRegistrationBefore($params)
    {
        if ($this->isAvailable(self::FORM_NEWSLETTER)) {
            if (!self::turnstileValidation()) {
                  if (!empty(static::$validationError)) {
                    $params['hookError'] = static::$validationError;
                } else {
                    $params['hookError'] = Context::getContext()->getTranslator()->trans(
                        'Security validation error',
                        [],
                        'Modules.Pixelcloudflareturnstile.Shop'
                    );
                }
            }
        }
    }

    /**
     * Check if turnstile is available for current action
     *
     * @param string $controllerClass
     * @param bool   $validate
     *
     * @return bool
     */
    protected function canProcess(string $controllerClass, bool $validate = false): bool
    {
        $isLoggedIn = $this->context->customer->isLogged();

        if ($controllerClass === 'OrderController') {
            return false;
        }

        // Contact
        if ($controllerClass === 'ContactController' && $this->isAvailable(self::FORM_CONTACT)) {
            if ($validate && !Tools::isSubmit('submitMessage')) {
                return false;
            }
            return true;
        }

        // Register
        if ($controllerClass === 'AuthController' &&
            $this->isAvailable(self::FORM_REGISTER) &&
            Tools::getValue('create_account') &&
            !$isLoggedIn
        ) {
            if ($validate && !Tools::isSubmit('submitCreate')) {
                return false;
            }
            return true;
        }

        // Register Prestashop >= 8.0.0
        if ($controllerClass === 'RegistrationController' &&
            $this->isAvailable(self::FORM_REGISTER) &&
            !$isLoggedIn
        ) {
            if ($validate && !Tools::isSubmit('submitCreate')) {
                return false;
            }
            return true;
        }

        // Login
        if ($controllerClass === 'AuthController' &&
            $this->isAvailable(self::FORM_LOGIN) &&
            !Tools::getValue('create_account') &&
            !$isLoggedIn
        ) {
            if ($validate && !Tools::isSubmit('submitLogin')) {
                return false;
            }
            return true;
        }

        // Reset Password
        if ($controllerClass === 'PasswordController' && $this->isAvailable(self::FORM_PASSWORD)) {
            if ($validate && (empty($_POST) || (isset($_POST['token'], $_POST['id_customer']) && !isset($_POST['email'])))) {
                return false;
            }
            return true;
        }

        return false;
    }

    /**
     * Check if turnstile is available for the form
     *
     * @param string $form
     *
     * @return bool
     */
    public function isAvailable(string $form): bool
    {
        return in_array($form, $this->getForms());
    }

    /**
     * Validate turnstile
     *
     * @return void
     * @throws Exception
     */
    public static function turnstileValidationAndRedirect(): void
    {
        if (!self::turnstileValidation()) {
            $referer = self::returnUrl();

            if (!empty(static::$validationError)) {
                $cookie  = Context::getContext()->cookie;
                $cookie->__set(
                    self::TURNSTILE_SESSION_ERROR_KEY,
                    static::$validationError
                );
            }

            Tools::redirect($referer);
        }
    }

    protected static function returnUrl(): string
    {
        $fallback = Context::getContext()->link->getPageLink('index');
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        $target = is_string($referer) ? parse_url($referer) : false;
        $origin = parse_url($fallback);
        if (!is_array($target) || preg_match('/[\x00-\x20\\\\]/', $referer)
            || !in_array($target['scheme'] ?? '', ['http', 'https'], true)
            || isset($target['user']) || isset($target['pass'])
            || strtolower($target['host'] ?? '') !== strtolower($origin['host'] ?? '')
            || ($target['scheme'] ?? '') !== ($origin['scheme'] ?? '')
            || ($target['port'] ?? null) !== ($origin['port'] ?? null)) {
            return $fallback;
        }
        return $referer;
    }

    /**
     * Validate turnstile
     *
     * @return bool
     * @throws Exception
     */
    public static function turnstileValidation(): bool
    {
        static::$validationError = null;
        $response = Tools::getValue('cf-turnstile-response');
        if (!is_string($response) || $response === '' || strlen($response) > 2048) {
            static::$validationError =
                Context::getContext()->getTranslator()->trans(
                    'Please validate the security field.',
                    [],
                    'Modules.Pixelcloudflareturnstile.Shop'
                )
            ;

            return false;
        }

        $secret = self::getSecretKeyStatic();
        if (!$secret) {
            static::$validationError = 'Security validation is unavailable. Please try again later.';
            return false;
        }
        $data = [
            'secret'   => $secret,
            'response' => $response,
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://challenges.cloudflare.com/turnstile/v0/siteverify');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);

        $curlResult = curl_exec($ch);
        if (!is_string($curlResult) || curl_getinfo($ch, CURLINFO_HTTP_CODE) !== 200) {
            static::$validationError = 'Security validation is unavailable. Please try again later.';

            return false;
        }

        $result = json_decode($curlResult, true);

        if (!is_array($result) || ($result['success'] ?? null) !== true) {
            $errors = is_array($result['error-codes'] ?? null) ? $result['error-codes'] : ['unavailable'];
            foreach ($errors as $key => $errorCode) {
                $errors[$key] = is_string($errorCode) ? self::getErrorMessage($errorCode) : self::getErrorMessage('unavailable');
            }
            static::$validationError =
                Context::getContext()->getTranslator()->trans(
                    'Security validation error:',
                    [],
                    'Modules.Pixelcloudflareturnstile.Shop'
                ) . ' ' . join(', ', $errors)
            ;

            return false;
        }

        return true;
    }

    /**
     * Retrieve error message from error code
     *
     * @param string $code
     *
     * @return string
     */
    protected static function getErrorMessage(string $code): string
    {
        $messages = [
            'missing-input-secret'   => 'the secret parameter was not passed.',
            'invalid-input-secret'   => 'the secret parameter was invalid or did not exist.',
            'missing-input-response' => 'the response parameter was not passed.',
            'invalid-input-response' => 'the response parameter is invalid or has expired.',
            'bad-request'            => 'the request was rejected because it was malformed.',
            'timeout-or-duplicate'   => 'the response parameter has already been validated before.',
            'internal-error'         => 'an internal error happened while validating the response. The request can be retried.',
            'unavailable'            => 'unable to contact Cloudflare to validate the form',
        ];

        return $messages[$code] ?? 'unknown error';
    }

    /*********************/
    /** FRONTEND WIDGET **/
    /*********************/

    /**
     * Render the turnstile widget
     *
     * @param string $hookName
     * @param string[] $configuration
     *
     * @return string
     */
    public function renderWidget($hookName, array $configuration): string
    {
        $className = get_class($this->context->controller);
        $isCustom = (int)($configuration['custom'] ?? 0) === 1;
        if (!$isCustom && (!$this->canProcess($className) && $hookName != 'displayNewsletterRegistration')) {
            return '';
        }
        $template = $this->context->smarty->createTemplate($this->templateFile, null, $this->getDefaultCompileId(), $this->smarty);
        $template->caching = Smarty::CACHING_OFF;
        $template->assign($this->getWidgetVariables($hookName, $configuration));
        return $template->fetch();
    }

    /**
     * Retrieve the widget variables
     *
     * @param string $hookName
     * @param string[] $configuration
     *
     * @return string[]
     */
    public function getWidgetVariables($hookName, array $configuration): array
    {
        $action = $configuration['action'] ?? $this->getFormName();
        if (!is_string($action) || !preg_match('/\A[a-zA-Z0-9_-]{1,32}\z/D', $action)) {
            throw new InvalidArgumentException('Invalid Turnstile action.');
        }
        $theme = $configuration['theme'] ?? $this->getTheme();
        $appearance = $configuration['appearance'] ?? $this->getAppearance();
        if (!in_array($theme, ['auto', 'light', 'dark'], true)
            || !in_array($appearance, ['always', 'execute', 'interaction-only'], true)) {
            throw new InvalidArgumentException('Invalid Turnstile widget options.');
        }
        return [
            'sitekey'    => $this->getSitekey(),
            'theme'      => $theme,
            'appearance' => $appearance,
            'action'     => $action,
        ];
    }

    /**
     * Retrieve the current form name
     *
     * @return string
     */
    public function getFormName(): string
    {
        $controllerClass = get_class($this->context->controller);
        switch ($controllerClass) {
            case 'ContactController':
                $action = self::FORM_CONTACT;
                break;
            case 'PasswordController':
                $action = self::FORM_PASSWORD;
                break;
            case 'AuthController':
                $action = Tools::getValue('create_account') ? self::FORM_REGISTER : self::FORM_LOGIN;
                break;
            default:
                $action = strtolower(str_replace('Controller', '', $controllerClass));
        }

        return $action;
    }

    /*************************/
    /** ADMIN CONFIGURATION **/
    /*************************/

    /**
     * Retrieve config fields
     *
     * @return array[]
     */
    protected function getConfigFields(): array
    {
        $fields = [
            self::CONFIG_CLOUDFLARE_TURNSTILE_SITEKEY => [
                'type'     => 'text',
                'label'    => $this->trans('Sitekey', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                'name'     => self::CONFIG_CLOUDFLARE_TURNSTILE_SITEKEY,
                'required' => true,
            ],
            self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY => [
                'type'     => 'password',
                'label'    => $this->trans('Secret key', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                'name'     => self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY,
                'required' => false,
                'desc' => $this->trans('Leave blank to keep the configured secret key.', [], 'Modules.Pixelcloudflareturnstile.Admin'),
            ],
            self::CONFIG_CLOUDFLARE_TURNSTILE_THEME => [
                'type'     => 'select',
                'label'    => $this->trans('Theme', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                'name'     => self::CONFIG_CLOUDFLARE_TURNSTILE_THEME,
                'required' => true,
                'options' => [
                    'query' => [
                        [
                            'value' => 'auto',
                            'name'  => 'Auto',
                        ],
                        [
                            'value' => 'light',
                            'name'  => 'Light',
                        ],
                        [
                            'value' => 'dark',
                            'name'  => 'Dark',
                        ],
                    ],
                    'id'   => 'value',
                    'name' => 'name',
                ],
            ],
            self::CONFIG_CLOUDFLARE_TURNSTILE_APPEARANCE => [
                'type'     => 'select',
                'label'    => $this->trans('Appearance', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                'name'     => self::CONFIG_CLOUDFLARE_TURNSTILE_APPEARANCE,
                'required' => true,
                'options' => [
                    'query' => [
                        [
                            'value' => 'always',
                            'name'  => $this->trans('Always visible', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => 'execute',
                            'name'  => $this->trans('Execute', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => 'interaction-only',
                            'name'  => $this->trans('Interaction only (invisible)', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                    ],
                    'id'   => 'value',
                    'name' => 'name',
                ],
            ],
            self::CONFIG_CLOUDFLARE_TURNSTILE_TEST_MODE => [
                'type'     => 'select',
                'label'    => $this->trans('Test mode', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                'name'     => self::CONFIG_CLOUDFLARE_TURNSTILE_TEST_MODE,
                'required' => false,
                'options' => [
                    'query' => [
                        [
                            'value' => self::TEST_MODE_DISABLED,
                            'name'  => $this->trans('Disabled (production)', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::TEST_MODE_PASS,
                            'name'  => $this->trans('Always passes', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::TEST_MODE_FAIL,
                            'name'  => $this->trans('Always fails', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::TEST_MODE_INTERACTIVE,
                            'name'  => $this->trans('Force interactive challenge', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                    ],
                    'id'   => 'value',
                    'name' => 'name',
                ],
                'desc' => $this->trans(
                    'Use Cloudflare test keys instead of real keys',
                    [],
                    'Modules.Pixelcloudflareturnstile.Admin'
                ),
            ],
            self::CONFIG_CLOUDFLARE_TURNSTILE_FORMS => [
                'type'     => 'select',
                'multiple' => true,
                'label'    => $this->trans('Forms to validate', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                'name'     => self::CONFIG_CLOUDFLARE_TURNSTILE_FORMS . '[]',
                'required' => false,
                'options' => [
                    'query' => [
                        [
                            'value' => self::FORM_CONTACT,
                            'name'  => $this->trans('Contact', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::FORM_LOGIN,
                            'name'  => $this->trans('Login', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::FORM_REGISTER,
                            'name'  => $this->trans('Register', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::FORM_PASSWORD,
                            'name'  => $this->trans('Reset Password', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                        [
                            'value' => self::FORM_NEWSLETTER,
                            'name'  => $this->trans('Newsletter', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                        ],
                    ],
                    'id'   => 'value',
                    'name' => 'name',
                ],
                'desc' => $this->trans(
                    'For contact, login and reset password forms, you need to manually add the widget in the template files.',
                    [],
                    'Modules.Pixelcloudflareturnstile.Admin'
                ),
            ],
        ];
        foreach ($fields as $code => &$field) {
            $field['id'] = $code;
        }
        unset($field);
        return $fields;
    }

    /**
     * This method handles the module's configuration page
     *
     * @return string
     * @throws Exception
     */
    public function getContent(): string
    {
        if (!$this->canConfigureSettings()) {
            return $this->displayError($this->trans('You cannot configure these settings.', [], 'Modules.Pixelcloudflareturnstile.Admin'));
        }
        $themeName = htmlspecialchars($this->getCurrentThemeName(), ENT_QUOTES, 'UTF-8');

        $message = $this->trans(
            'For contact, login and reset password forms, you need to manually add the widget in the template files.',
            [],
            'Modules.Pixelcloudflareturnstile.Admin'
        );
        $message .= '<br /><br />{widget name=\'pixel_cloudflare_turnstile\'}<br />';
        $message .= '<br /><strong>- Contact:</strong> themes/' . $themeName . '/modules/contactform/views/templates/widget/contactform.tpl';
        $message .= '<br /><strong>- Login:</strong> themes/' . $themeName . '/templates/customer/_partials/login-form.tpl';
        $message .= '<br /><strong>- Reset password:</strong> themes/' . $themeName . '/templates/customer/password-email.tpl';

        $output = '<div class="alert alert-info" style="overflow-wrap:anywhere">' . $message . '</div>';

        if (Tools::isSubmit('submit' . $this->name)) {
            if (!$this->isSettingsWriteAllowed()) {
                return $this->displayError(
                    $this->trans('You cannot save these settings.', [], 'Modules.Pixelcloudflareturnstile.Admin')
                ) . $this->displayForm();
            }

            // Validate every field before changing any stored configuration.
            $values = [];
            foreach ($this->getConfigFields() as $code => $field) {
                $value = $_POST[$code] ?? false;
                if ($code === self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY && $value === '') {
                    $value = Configuration::get($code);
                }
                $multiple = ($field['multiple'] ?? false) === true;
                $allowed = isset($field['options']) ? array_column($field['options']['query'], 'value') : [];
                if ($multiple && $value === false) {
                    $value = [];
                } elseif ($code === self::CONFIG_CLOUDFLARE_TURNSTILE_TEST_MODE && $value === false) {
                    $value = self::TEST_MODE_DISABLED;
                }

                $valid = true;
                if ($multiple) {
                    $valid = is_array($value);
                    if ($valid) {
                        foreach ($value as $selection) {
                            if (!is_string($selection) || !in_array($selection, $allowed, true)) {
                                $valid = false;
                                break;
                            }
                        }
                    }
                } else {
                    $valid = is_string($value);
                    if ($valid && ($field['required'] || $code === self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY) && (trim($value) === '' || strlen($value) > 2048)) {
                        $valid = false;
                    }
                    if ($valid && $allowed && !in_array($value, $allowed, true)) {
                        $valid = false;
                    }
                }

                if (!$valid) {
                    return $this->displayError(
                        $this->trans(
                            '%field% is invalid',
                            ['%field%' => $field['label']],
                            'Modules.Pixelcloudflareturnstile.Admin'
                        )
                    ) . $this->displayForm();
                }
                $values[$code] = $multiple ? join(',', $value) : $value;
            }

            $db = Db::getInstance();
            if (!$db->execute('START TRANSACTION')) return $this->displayError($this->trans('Settings could not be saved.', [], 'Modules.Pixelcloudflareturnstile.Admin')) . $this->displayForm();
            try {
                foreach ($values as $code => $value) {
                    if (!Configuration::updateValue($code, $value)) {
                        throw new \RuntimeException('Configuration update failed');
                    }
                }
                if (!$db->execute('COMMIT')) throw new RuntimeException('Commit failed');
            } catch (\Throwable $error) {
                $db->execute('ROLLBACK');
                Configuration::resetStaticCache();
                return $this->displayError(
                    $this->trans(
                        'Settings were not saved. Reload this page before retrying.',
                        [],
                        'Modules.Pixelcloudflareturnstile.Admin'
                    )
                ) . $this->displayForm();
            }

            $output .= $this->displayConfirmation(
                $this->trans('Settings updated', [], 'Modules.Pixelcloudflareturnstile.Admin')
            );
        }

        return $output . $this->displayForm();
    }

    /**
     * Retrieve current theme name
     *
     * @return string
     * @throws Exception
     */
    public function getCurrentThemeName(): string
    {
        return basename(Context::getContext()->shop->theme->getName());
    }

    /**
     * Builds the configuration form
     *
     * @return string
     */
    public function displayForm(): string
    {
        $form = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Settings', [], 'Modules.Pixelcloudflareturnstile.Admin') . ' (' . $this->installedVersion() . ')',
                ],
                'input' => array_merge(array_values($this->getConfigFields()), [['type' => 'hidden', 'name' => 'turnstile_form_token']]),
                'submit' => [
                    'title' => $this->trans('Save', [], 'Modules.Pixelcloudflareturnstile.Admin'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this;

        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false, [], ['configure' => $this->name]);
        $helper->submit_action = 'submit' . $this->name;

        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->fields_value['turnstile_form_token'] = $this->settingsFormToken();

        foreach ($this->getConfigFields() as $code => $field) {
            $value = Tools::getValue($code, Configuration::get($code));
            if (($field['multiple'] ?? false) === true) {
                if (!is_array($value)) {
                    $value = is_string($value) && $value !== '' ? explode(',', $value) : [];
                }
                $value = array_values(array_filter($value, 'is_string'));
            } elseif (!is_string($value)) {
                $value = '';
            }
            $helper->fields_value[$field['name']] = $code === self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY ? '' : $value;
        }

        return $helper->generateForm([$form]);
    }

    /**
     * Retrieve available forms for turnstile
     *
     * @return string[]
     */
    public function getForms(): array
    {
        $forms = Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_FORMS);
        if (!$forms) {
            return [];
        }

        return explode(',', $forms);
    }

    /**
     * Retrieve the theme
     *
     * @return string
     */
    public function getTheme(): string
    {
        return Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_THEME) ?: 'auto';
    }

    /**
     * Retrieve the appearance mode
     *
     * @return string
     */
    public function getAppearance(): string
    {
        return Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_APPEARANCE) ?: 'always';
    }

    /**
     * Retrieve the test mode
     *
     * @return string
     */
    public function getTestMode(): string
    {
        $mode = Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_TEST_MODE) ?: self::TEST_MODE_DISABLED;
        return is_string($mode) && isset(self::TEST_KEYS[$mode]) ? $mode : self::TEST_MODE_DISABLED;
    }

    /**
     * Retrieve the secret key
     *
     * @return string|null
     */
    protected function getSecretKey(): ?string
    {
        return self::getSecretKeyStatic();
    }

    /**
     * Retrieve the secret key (static version for validation)
     *
     * @return string|null
     */
    protected static function getSecretKeyStatic(): ?string
    {
        $testMode = Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_TEST_MODE) ?: self::TEST_MODE_DISABLED;
        if (is_string($testMode) && isset(self::TEST_KEYS[$testMode])) {
            return self::TEST_KEYS[$testMode]['secret'];
        }
        return Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY) ?: null;
    }

    /**
     * Retrieve the sitekey
     *
     * @return string|null
     */
    protected function getSitekey(): ?string
    {
        $testMode = $this->getTestMode();
        if ($testMode !== self::TEST_MODE_DISABLED) {
            $keyType = $this->getAppearance() === 'interaction-only' ? 'sitekey_invisible' : 'sitekey_visible';
            return self::TEST_KEYS[$testMode][$keyType];
        }
        return Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_SITEKEY) ?: null;
    }


    public function canConfigureSettings(): bool
    {
        $employee = $this->context->employee ?? null;
        $shop = $this->context->shop ?? null;
        return $employee instanceof Employee && Validate::isLoadedObject($employee)
            && $employee->active && $employee->isLoggedBack()
            && $this->getPermission('configure', $employee)
            && Shop::getContext() === Shop::CONTEXT_SHOP && $shop instanceof Shop
            && Validate::isLoadedObject($shop) && $shop->active && !$shop->deleted
            && (int) Shop::getContextShopID() === (int) $shop->id
            && $employee->hasAuthOnShop((int) $shop->id);
    }

    public function settingsFormToken(): string
    {
        $container = PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance();
        $session = $container->get('request_stack')->getSession();
        $key = 'turnstile_settings_' . (int) $this->context->employee->id;
        if (!$session->has($key)) $session->set($key, bin2hex(random_bytes(32)));
        return (string) $session->get($key);
    }

    public function isSettingsWriteAllowed(): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !$this->canConfigureSettings()) return false;
        try {
            $container = PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance();
            $token = $_POST['turnstile_form_token'] ?? null;
            return $container->get(PrestaShopBundle\Security\Admin\UserTokenManager::class)->isTokenValid()
                && is_string($token) && hash_equals($this->settingsFormToken(), $token);
        } catch (Throwable $error) { return false; }
    }

    private function installedVersion(): string
    {
        $version = Db::getInstance()->getValue("SELECT version FROM `" . _DB_PREFIX_ . "module` WHERE name='pixel_cloudflare_turnstile'", false);
        return htmlspecialchars($version === false ? 'Unavailable' : (string) $version, ENT_QUOTES, 'UTF-8');
    }

    public function isMcpCompliant(): bool
    {
        return true;
    }

    /** Diagnostic only: never returns key material or contacts Cloudflare. */
    public function getStatus(): array
    {
        $shop = Context::getContext()->shop ?? null;
        if (Shop::getContext() !== Shop::CONTEXT_SHOP || !$shop instanceof Shop
            || !Validate::isLoadedObject($shop) || !$shop->active || $shop->deleted
            || (int) $shop->id <= 0 || (int) Shop::getContextShopID() !== (int) $shop->id) {
            throw new DomainException('Select one active shop to read Turnstile status.');
        }
        $db = Db::getInstance();
        $row = $db->getRow('SELECT m.version FROM `' . _DB_PREFIX_ . 'module` m'
            . ' INNER JOIN `' . _DB_PREFIX_ . 'module_shop` ms ON ms.id_module=m.id_module'
            . " WHERE m.name='pixel_cloudflare_turnstile' AND m.active=1 AND ms.id_shop=" . (int) $shop->id, false);
        if ((int) $db->getNumberError() !== 0) throw new RuntimeException('Unable to read installation status.');
        if (!is_array($row) || !isset($row['version'])) throw new DomainException('Turnstile is not enabled for this shop.');
        $hooks = [];
        foreach (['actionFrontControllerSetMedia', 'displayCustomerAccountForm', 'displayNewsletterRegistration',
            'actionNewsletterRegistrationBefore', 'actionFrontControllerInitBefore'] as $hook) {
            $hooks[$hook] = $this->isRegisteredInHook($hook);
        }
        return [
            'shop_id' => (int) $shop->id,
            'installed_version' => (string) $row['version'],
            'code_version' => $this->version,
            'forms' => array_values(array_intersect($this->getForms(), [self::FORM_CONTACT, self::FORM_LOGIN,
                self::FORM_REGISTER, self::FORM_PASSWORD, self::FORM_NEWSLETTER])),
            'test_mode' => $this->getTestMode(),
            'sitekey_configured' => (bool) Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_SITEKEY),
            'secret_configured' => (bool) Configuration::get(self::CONFIG_CLOUDFLARE_TURNSTILE_SECRET_KEY),
            'hooks' => $hooks,
            'note' => 'Contact, login and password templates need widget placement. This read does not test Cloudflare or validate theme placement.',
        ];
    }
}

require_once __DIR__ . '/src/Mcp/StatusResource.php';
